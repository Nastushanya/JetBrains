import java.util.Scanner;

import static java.lang.Math.*;

class SimpleBot {
    final static Scanner SCANNER1 = new Scanner(System.in); // Do not change this line

    public static void main(String[] args) {
        int k = remindName();
        switch(k) {
            case 1: {
                double a1 = SCANNER1.nextDouble();
                double b1 = SCANNER1.nextDouble();
                double c1 = SCANNER1.nextDouble();
                System.out.println(triangle_square(a1,b1,c1));
            };
            break;
            case 2: {
                double a1 = SCANNER1.nextDouble();
                double b1 = SCANNER1.nextDouble();
                System.out.println(rectangle_square(a1,b1));
            };
            break;
            case 3: {
                double a1 = SCANNER1.nextDouble();
                System.out.println(circle_square(a1));
            };
            break;
            default: System.out.println(0);
        }

    }


    static int remindName() {
        String name = SCANNER1.nextLine();
        if (name.equals("triangle")) {
            return 1;
        }
        if (name.equals("rectangle")) {
            return 2;
        }
        if (name.equals("circle")) {
            return 3;
        }
        return 0;
    }


    static double triangle_square(double a, double b, double c) {
        double peri = (a + b + c) / 2;
        double square = sqrt(peri * (peri - a) * (peri - b) * (peri - c));
        return square;
    }
    static double rectangle_square(double a, double b) {
        return a * b;
    }
    static double circle_square(double a) {
        return a * a * 3.14;
    }
    

}
