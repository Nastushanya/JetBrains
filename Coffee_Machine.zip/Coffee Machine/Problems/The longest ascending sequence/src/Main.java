class Main {
    public static void main(String[] args) {
        // put your code here
    }
}