import java.util.Arrays;
import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String str = scanner.nextLine();
        int[] array = Arrays.stream(str.split(" ")).mapToInt(Integer::parseInt).toArray();
        int length = array.length;
        int n = scanner.nextInt(); // reading a length
        int con;
        n = n % length;
        for (int k = 0; k < n; k++) {
            con = array[length - 1];
            for (int i = length - 1; i > 0; i--) {
                array[i] = array[i - 1];
            }
            array[0] = con;
        }
        for (int i = 0; i < length; i++) {
            System.out.print(array[i] + " ");
        }
    }
}
