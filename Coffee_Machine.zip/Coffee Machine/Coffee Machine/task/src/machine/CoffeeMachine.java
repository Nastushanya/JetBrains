package machine;

import java.util.Scanner;

public class CoffeeMachine {

    public static void main(String[] args) {
        int milk = 540;
        int water = 400;
        int beans = 120;
        int cups = 9;
        int money = 550;
        Scanner scanner = new Scanner(System.in);

        int variant = -1;
        while (variant != 5) {
            System.out.println("Write action (buy, fill, take, remaining, exit):");
            String option = scanner.nextLine();
            variant = operation(option);
            switch (variant) {
                case 5 : {
                    scanner.close();
                    System.exit(0);
                };
                case 4 : {
                    printBalance(water, milk, beans, cups, money);
                };
                break;
                case 1: {
                    System.out.println("What do you want to buy? 1 - espresso, 2 - latte, 3 - cappuccino, back - to main menu:");
                    if (scanner.hasNextInt()) {
                        int coffee = scanner.nextInt();
                        switch (coffee) {
                            case 1: {
                                if ( water < 250 ) {
                                    System.out.println("Sorry, not enough water!"); break ;
                                }
                                if ( beans < 16 ) {
                                    System.out.println("Sorry, not enough beans!"); break ;
                                }
                                if ( cups < 1 ) {
                                    System.out.println("Sorry, not enough cups!"); break ;
                                }
                                System.out.println("I have enough resources, making you a coffee!");
                                water -= 250;
                                beans -= 16;
                                cups--;
                                money += 4;
                            }
                            ;
                            break;
                            case 2: {
                                if ( water < 350 ) {
                                    System.out.println("Sorry, not enough water!"); break ;
                                }
                                if ( milk < 75 ) {
                                    System.out.println("Sorry, not enough milk!"); break ;
                                }
                                if ( beans < 20 ) {
                                    System.out.println("Sorry, not enough beans!"); break ;
                                }
                                if ( cups < 1 ) {
                                    System.out.println("Sorry, not enough cups!"); break ;
                                }
                                System.out.println("I have enough resources, making you a coffee!");
                                water -= 350;
                                milk -= 75;
                                beans -= 20;
                                cups--;
                                money += 7;
                            }
                            ;
                            break;
                            case 3: {
                                if ( water < 200 ) {
                                    System.out.println("Sorry, not enough water!"); break ;
                                }
                                if ( milk < 100 ) {
                                    System.out.println("Sorry, not enough milk!"); break ;
                                }
                                if ( beans < 12 ) {
                                    System.out.println("Sorry, not enough beans!"); break ;
                                }
                                if ( cups < 1 ) {
                                    System.out.println("Sorry, not enough cups!"); break ;
                                }
                                System.out.println("I have enough resources, making you a coffee!");
                                water -= 200;
                                milk -= 100;
                                beans -= 12;
                                cups--;
                                money += 6;
                            }
                            ;
                            break;
                            default: {
                                System.out.println("Please, try again! Choose the one of available options");
                                printBalance(water, milk, beans, cups, money);
                            }
                            ;
                        }
                    } else break;
                }
                ;
                break;
                case 2: {
                    System.out.println("Write how many ml of water do you want to add: ");
                    water += scanner.nextInt();
                    System.out.println("Write how many ml of milk do you want to add:");
                    milk += scanner.nextInt();
                    System.out.println("Write how many grams of coffee beans do you want to add:");
                    beans += scanner.nextInt();
                    System.out.println("Write how many disposable cups of coffee do you want to add:");
                    cups += scanner.nextInt();

                }
                ;
                break;
                case 3: {
                    System.out.printf("I gave you $%d \n\n", money);
                    money = 0;

                }
                ;
                break;
                default: {
                    System.out.println("Please, try again! Choose the one of available options");

                }
            }
        }
    }
    public static int operation(String opt){
        if (opt.equals("buy")) return 1;
        if (opt.equals("fill")) return 2;
        if (opt.equals("take")) return 3;
        if (opt.equals("remaining")) return 4;
        if (opt.equals("exit")) return 5;
        return 0;
    }
    public static void printBalance (int water, int milk, int beans, int cups, int money)
    {
        System.out.println("The coffee machine has:");
        System.out.printf("%d of water\n", water);
        System.out.printf("%d of milk\n", milk);
        System.out.printf("%d of coffee beans\n", beans);
        System.out.printf("%d of disposable cups\n", cups);
        System.out.printf("%d of money\n", money);
    }
}
